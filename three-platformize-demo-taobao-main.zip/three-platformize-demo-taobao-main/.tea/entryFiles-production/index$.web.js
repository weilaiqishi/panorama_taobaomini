require('@alipay/appx-compiler/lib/sjsEnvInit');
require('./config$');

require('../../pages/index/index?hash=32d7d2807ed4e666ef03b4b3fe8c38ecf2e34e68');
